package servlet;

import java.io.IOException;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import bean.OrderedItem;
import dao.OrderedItemDAO;

@WebServlet("/showOrderedItem")
public class ShowOrderedItemServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * 購入履歴（注文情報）を表示します。
		 * OrderedItemDAO により購入情報を取得し、showOrderedItem.jsp にフォワードします。
		 *
		 * @param request  HttpServletRequest リクエスト情報
		 * @param response HttpServletResponse レスポンス情報
		 * @throws ServletException サーブレット処理中の例外
		 * @throws IOException      入出力例外
		 */
		String path = "/view/showOrderedItem.jsp";
		String error = null;
		String cmd = "logout";

		try {
			// ① OrderedItemDAOをインスタンス化し、関連メソッドを呼び出す。
			OrderedItemDAO orderedItemDao = new OrderedItemDAO();
			
			// ② 戻り値として、OrderedItemオブジェクトのリスト(List)を取得する。
			ArrayList<OrderedItem> list = orderedItemDao.selectAll();

			// ③ 取得したListをリクエストスコープに"ordered_list"という名前で格納する。
			request.setAttribute("ordered_list", list);

			return; // 正常終了（finallyでフォワード）

		} catch (Exception e) {
			error = "DB接続エラーの為、購入状況確認は出来ません。";
			cmd = "logout";
			return;
		} finally {
			if (error != null) {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			} else {
				request.getRequestDispatcher(path).forward(request, response);
			}
		}
	}
}