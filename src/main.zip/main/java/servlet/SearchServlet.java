/*
 * プロジェクト名：書籍管理システムWeb版Ver1.0
 * プログラム名：SearchServlet.java
 * プログラムの説明：書籍情報の検索処理を制御するサーブレットクラス。
 * 作成日：2026年5月12日
 * 作成者：髙垣湧侑翔
*/

package servlet;

import java.io.IOException;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import bean.Book;
import dao.BookDAO;

/**
 * 書籍の絞り込み検索処理を制御するサーブレットクラスです。
 */
@WebServlet("/search")
public class SearchServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/**
		 * ISBN、タイトル、価格を条件に書籍を検索します。
		 * 条件に合致した書籍を取得し、list.jsp にフォワードします。DB エラー時は error.jsp にフォワードします。
		 *
		 * @param request  HttpServletRequest リクエスト情報
		 * @param response HttpServletResponse レスポンス情報
		 * @throws ServletException サーブレット処理中の例外
		 * @throws IOException      入出力例外
		 */

		request.setCharacterEncoding("UTF-8");

		String isbn = request.getParameter("isbn");
		String title = request.getParameter("title");
		String price = request.getParameter("price");

		String path = "/view/list.jsp";
		String error = null;
		String cmd = "logout";

		try {
			BookDAO dao = new BookDAO();
			ArrayList<Book> list = dao.search(isbn, title, price);

			request.setAttribute("book_list", list);
			return; // 正常終了（finallyでフォワード）

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "logout";
			return;
		} finally {
			if (error != null) {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			} else {
				request.getRequestDispatcher(path).forward(request, response);
			}
		}
	}
}
