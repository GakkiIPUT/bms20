package servlet;


import java.io.IOException;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import bean.Book;
import dao.BookDAO;
import util.FileIn;


@WebServlet("/insertIniData")
public class InsertIniDataServlet extends HttpServlet {


    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 初期データ（CSV）をデータベースに登録します。
         * データベースが空の場合のみ /file/initial_data.csv を読み込み、各行を Book として登録します。
         * 成功時は insertIniData.jsp にフォワードし、エラー時は error.jsp にフォワードします。
         *
         * @param request  HttpServletRequest リクエスト情報
         * @param response HttpServletResponse レスポンス情報
         * @throws ServletException サーブレット処理中の例外
         * @throws IOException      入出力例外（CSV が無い等）
         */
        String path = "/view/insertIniData.jsp";
        String error = null;
        String cmd = "menu";

        try {
            // ① BookDAOをインスタンス化し、関連メソッドを呼び出す
            BookDAO bookDao = new BookDAO();
            
            // ② 戻り値として、Bookオブジェクトのリスト(List)を取得する
            ArrayList<Book> list = bookDao.selectAll();
            
            // ③ Listに1件でも書籍データがあればerror.jspにフォワードする
            if (list.size() > 0) {
                error = "DBにはデータが存在するので、初期データは登録できません。";
                cmd = "menu";
                return;
            }
            
            // ④ 初期データ用CSVファイルよりデータを取得する
            FileIn fileIn = new FileIn();
            String pathCsv = getServletContext().getRealPath("/file/initial_data.csv");
            
            ArrayList<Book> bookList = new ArrayList<>();
            if (fileIn.open(pathCsv)) {
                String line;
                while ((line = fileIn.readLine()) != null) {
                    // CSV形式(isbn,title,price)を分割
                    String[] data = line.split(",");
                    
                    // ⑤ Bookのオブジェクトを生成し、初期データの値を設定する
                    Book book = new Book();
                    book.setIsbn(data[0]);
                    book.setTitle(data[1]);
                    book.setPrice(Integer.parseInt(data[2]));
                    
                    // ⑥ 取得した各BookをListに追加し、DAOで登録を行う
                    bookList.add(book);
                    // ⑦ 関連メソッド(insert)を呼び出す
                    bookDao.insert(book);
                }
                fileIn.close();
            } else {
                throw new IOException("初期データファイルが無い為、登録は行えません。");
            }
            
            // リクエストスコープに登録したリストを格納
            request.setAttribute("book_list", bookList);

            return; // 正常終了（finallyでフォワード）

        } catch (Exception e) {
            error = "初期データ登録中にエラーが発生しました：" + e.getMessage();
            cmd = "menu";
            return;
        } finally {
            if (error != null) {
                request.setAttribute("error", error);
                request.setAttribute("cmd", cmd);
                request.getRequestDispatcher("/view/error.jsp").forward(request, response);
            } else {
                request.getRequestDispatcher(path).forward(request, response);
            }
        }
    }
}