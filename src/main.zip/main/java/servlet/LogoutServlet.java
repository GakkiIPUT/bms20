package servlet;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {

    /**
     * ログアウト処理を行います。セッションを無効化し、ログインページへフォワードします。
     *
     * @param request  HttpServletRequest リクエスト情報
     * @param response HttpServletResponse レスポンス情報
     * @throws ServletException サーブレット処理中の例外
     * @throws IOException      入出力例外
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = "/view/login.jsp";
        String error = null;
        String cmd = "";

        try {
            // ① セッション情報をクリアする
            HttpSession session = request.getSession();
            if (session != null) {
                session.invalidate();
            }
            return; // 正常終了（finallyでフォワード）

        } finally {
            if (error != null) {
                request.setAttribute("error", error);
                request.setAttribute("cmd", cmd);
                request.getRequestDispatcher("/view/error.jsp").forward(request, response);
            } else {
                request.getRequestDispatcher(path).forward(request, response);
            }
        }
    }
}