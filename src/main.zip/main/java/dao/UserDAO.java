/*
 * プロジェクト名：書籍管理システムWeb版Ver2.0
 * プログラム名：UserDAO.java
 * プログラムの説明：DB接続とuserinfoテーブルに対するユーザー情報の取得や
 * 					パスワードに合致する情報を取得するSQL実行を担当する。
 * 作成日：2026年5月15日
 * 作成者：髙垣湧侑翔
*/

package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.User;

/**
 */
public class UserDAO {

	// 接続用の情報をフィールドに定数として定義
	private static String RDB_DRIVE = "com.mysql.cj.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/mybookdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	/**
	 * データベースへのコネクションを取得します。
	 * @return 確立されたデータベース接続（Connectionオブジェクト）
	 * @throws IllegalStateException JDBCドライバーのロードや接続に失敗した場合にスローされます
	 */
	private static Connection getConnection() {
		try {
			// JDBCドライバーをメモリにロードする
			Class.forName(RDB_DRIVE);
			// URL、ユーザー名、パスワードを使用してデータベースへの接続を確立する
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/**
	 * Selects a user by userid.
	 *
	 * @param userid the user id to search for
	 * @return User DTO if found; null otherwise
	 * @throws IllegalStateException when a database error occurs
	 */
	public User selectByUser(String userid) {
		Connection con = null;
		PreparedStatement pstmt = null;
		User user = null;

		String sql = "SELECT * FROM userinfo WHERE user =?";

		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userid);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				user = new User();
				user.setUserid(rs.getString("user"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setAuthority(rs.getString("authority"));
			}
		} catch (SQLException e) {
			throw new IllegalStateException(e);
		} finally {
			closeResources(con, pstmt);
		}
		return user;
	}

	/**
	 * Selects a user by userid and password (used for authentication).
	 *
	 * @param userid   the user id to search for
	 * @param password the password to match
	 * @return User DTO if credentials match; null otherwise
	 * @throws IllegalStateException when a database error occurs
	 */
	public User selectByUser(String userid, String password) {
		Connection con = null;
		PreparedStatement pstmt = null;
		User user = null;

		String sql = "SELECT * FROM userinfo WHERE user = ? AND password = ?";

		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, userid);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				user = new User();
				user.setUserid(rs.getString("user"));
				user.setPassword(rs.getString("password"));
				user.setEmail(rs.getString("email"));
				user.setAuthority(rs.getString("authority"));
			}
		} catch (SQLException e) {
			throw new IllegalStateException(e);
		} finally {
			closeResources(con, pstmt);
		}
		return user;
	}

	private void closeResources(Connection con, PreparedStatement pstmt) {
		try {
			if (pstmt != null)
				pstmt.close();
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
