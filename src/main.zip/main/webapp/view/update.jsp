<%--
プロジェクト名：書籍管理システムWeb版Ver2.0
 プログラム名：update.jsp
 プログラムの説明：特定の書籍情報を編集するための入力画面。
 作成日：2026年5月18日
 作成者：髙垣湧侑翔
 --%>

<%@ page language="java" contentType="text/html; charset=UTF-8"
	import="bean.Book, util.MyFormat"%>
<%
Book book = (Book) request.getAttribute("book");
MyFormat format = new MyFormat();
%>

<!DOCTYPE html>
<html>
<head>
<title>書籍変更</title>
<link rel="stylesheet" href="<%= request.getContextPath() %>/CSS/style.css">
</head>
<body>
	<%@ include file="/common/header.jsp"%>

	<div class="nav-header">
		<div class="nav-header-links">
			<a href="<%=request.getContextPath()%>/view/menu.jsp">[メニュー]</a>
			<a href="<%=request.getContextPath()%>/view/insert.jsp">[書籍登録]</a>
			<a href="<%=request.getContextPath()%>/list">[書籍一覧]</a>
		</div>
		<div class="nav-header-title">
			<h2>書籍変更</h2>
		</div>
	</div>

	<hr align="center" size="2" color="green" width="100%">

	<form action="<%=request.getContextPath()%>/update" method="get">
		<input type="hidden" name="isbn" value="<%=book.getIsbn()%>">
		<br>
		<table align="center">
			<tr>
				<th class="table-header-width-10"></th>
				<th class="table-header-width-30">&lt;&lt;変更前情報&gt;&gt;</th>
				<th class="table-header-width-5"></th>
				<th class="table-header-width-30">&lt;&lt;変更後情報&gt;&gt;</th>
			</tr>
			<tr>
				<td class="form-row-header-full">ISBN</td>
				<td align="center" class="form-row-info"><%=book.getIsbn()%></td>
				<td></td>
				<td align="center"><%=book.getIsbn()%></td>
			</tr>
			<tr>
				<td class="form-row-header-full">TITLE</td>
				<td align="center" class="form-row-info"><%=book.getTitle()%></td>
				<td></td>
				<td align="center"><input type="text" name="title" value=""></td>
			</tr>
			<tr>
				<td class="form-row-header-full">価格</td>
				<td align="center" class="form-row-info"><%=format.moneyFormat(book.getPrice())%></td>
				<td></td>
				<td align="center"><input type="text" name="price" value=""></td>
			<tr>
				<td><br></td>
			</tr>
			<tr>
				<td><br></td>
			</tr>
			<tr>
				<td><br></td>
			</tr>
			<tr>
				<td colspan="4" align="center"><input type="submit"
					value="変更完了"></td>
			</tr>
		</table>
	</form>
	<%@ include file="/common/footer.jsp"%>
</body>
</html>