<%--
 プロジェクト名：書籍管理システムWeb版Ver2.0
 プログラム名：login.jsp
 プログラムの説明：ログイン画面。
 作成日：2026年5月18日
 作成者：髙垣湧侑翔
 --%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
	// エラーメッセージの受け取り
	String message = (String) request.getAttribute("message");
	if (message == null) message = "";

	// ★追加：クッキーから過去のユーザーIDとパスワードを取得
	String cookieUser = "";
	String cookiePass = "";
	Cookie[] cookies = request.getCookies();
	if (cookies != null) {
		for (Cookie c : cookies) {
			if ("user".equals(c.getName())) cookieUser = c.getValue();
			if ("password".equals(c.getName())) cookiePass = c.getValue();
		}
	}
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>ログイン</title>
<link rel="stylesheet" href="<%= request.getContextPath() %>/CSS/style.css">
</head>
<body>
	<%@ include file="/common/header.jsp"%>

	<h2 align="center">ログイン</h2>
	<hr align="center" size="2" color="black" width="100%">
	<p align="center" class="error-title"><%= message %></p>

	<form action="<%= request.getContextPath() %>/login" method="post">
		<table align="center">
			<tr>
				<th class="header-blue">ユーザー</th>
				<td><input type="text" name="user" class="border-gray" value="<%= cookieUser %>"></td>
			</tr>
			<tr>
				<th class="header-blue">パスワード</th>
				<td><input type="password" name="password" class="border-gray" value="<%= cookiePass %>"></td>
			</tr>
			<tr>
				<td colspan="2" align="center">
					<input type="submit" value="ログイン">
				</td>
			</tr>
		</table>
	</form>

	<%@ include file="/common/footer.jsp"%>
</body>
</html>